
# lstm_multi_source_trainer.py
# ============================================================
# ✅ Uses Alpha Vantage for price
# ✅ Uses NewsAPI + Finnhub for sentiment
# ✅ Builds 2-layer LSTM
# ✅ Saves model as lstm_model_news_sentiment.h5
# ✅ Saves scaler as scaler_multi.save
# ============================================================

import numpy as np
import pandas as pd
import requests
import joblib
from keras.models import Sequential
from keras.layers import LSTM, Dense, Dropout
from sklearn.preprocessing import MinMaxScaler
from alpha_vantage.timeseries import TimeSeries
from datetime import datetime, timedelta

# === API KEYS ===
ALPHA_KEY = "9PS072YH49GZ1AIR"
NEWSAPI_KEY = "e5e6fbb2da3b4cfe985e68975d2bbc51"
FINNHUB_KEY = "d33qclpr01qib1p25fngd33qclpr01qib1p25fo0"

# === Fetch historical price data ===
def fetch_alpha(symbol="EURUSD"):
    ts = TimeSeries(key=ALPHA_KEY, output_format='pandas')
    data, _ = ts.get_intraday(symbol=symbol, interval='15min', outputsize='full')
    return data['4. close'].iloc[::-1].reset_index(drop=True)

# === NewsAPI Sentiment (basic polarity scoring) ===
def get_news_sentiment():
    url = f"https://newsapi.org/v2/everything?q=forex&apiKey={NEWSAPI_KEY}&pageSize=50"
    r = requests.get(url).json()
    articles = r.get("articles", [])
    pos, neg = 0, 0
    for a in articles:
        t = (a["title"] + a.get("description", "")).lower()
        if any(word in t for word in ["rise", "profit", "gain", "strong", "growth"]):
            pos += 1
        if any(word in t for word in ["fall", "loss", "drop", "weak", "fear"]):
            neg += 1
    return (pos - neg) / max((pos + neg), 1)

# === Finnhub Sentiment ===
def get_finnhub_sentiment():
    r = requests.get(f"https://finnhub.io/api/v1/news-sentiment?symbol=AAPL&token={FINNHUB_KEY}").json()
    return r.get("sentiment", {}).get("bullishPercent", 50) / 100

# === Build feature matrix ===
def build_dataset(prices, sentiment_score, finnhub_sentiment, window=60):
    scaler = MinMaxScaler()
    scaled_prices = scaler.fit_transform(prices.values.reshape(-1, 1))

    X, y = [], []
    for i in range(window, len(scaled_prices)-1):
        window_slice = scaled_prices[i-window:i]
        sentiment_column = np.full((window, 1), sentiment_score)
        finnhub_column = np.full((window, 1), finnhub_sentiment)
        feature_stack = np.hstack((window_slice, sentiment_column, finnhub_column))
        X.append(feature_stack)
        y.append(scaled_prices[i+1])  # next time step

    X, y = np.array(X), np.array(y)
    return X, y, scaler

# === Train LSTM model ===
def train_lstm(X, y):
    model = Sequential()
    model.add(LSTM(64, return_sequences=True, input_shape=(X.shape[1], X.shape[2])))
    model.add(Dropout(0.2))
    model.add(LSTM(32))
    model.add(Dropout(0.2))
    model.add(Dense(1))
    model.compile(optimizer='adam', loss='mse')
    model.fit(X, y, epochs=10, batch_size=32, verbose=1)
    return model

# === Main Execution ===
if __name__ == "__main__":
    prices = fetch_alpha("EURUSD")
    sentiment_score = get_news_sentiment()
    finnhub_score = get_finnhub_sentiment()
    X, y, scaler = build_dataset(prices, sentiment_score, finnhub_score)

    model = train_lstm(X, y)
    model.save("lstm_model_news_sentiment.h5")
    joblib.dump(scaler, "scaler_multi.save")
    print("✅ LSTM model (multi-source) saved!")
