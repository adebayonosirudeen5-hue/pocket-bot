
# app.py (Streamlit Interface with LSTM Integration, Pocket Option Auto-Trade, Telegram Alerts)

import streamlit as st
import pandas as pd
import numpy as np
import requests
import json
import joblib
import time
from datetime import datetime
from keras.models import load_model
from alpha_vantage.timeseries import TimeSeries
from telegram import Bot

# ====== CONFIGURATION ======
ALPHA_KEY = "9PS072YH49GZ1AIR"
NEWSAPI_KEY = "e5e6fbb2da3b4cfe985e68975d2bbc51"
FINNHUB_KEY = "d33qclpr01qib1p25fngd33qclpr01qib1p25fo0"
POCKET_TRADE_URL = "https://pocketoption.com/api/trade"
TRADE_LIMIT = 8

st.set_page_config(page_title="MarketBrain AI", layout="wide")

# ====== SESSION STATE ======
if "trade_count" not in st.session_state:
    st.session_state.trade_count = 0
if "model" not in st.session_state:
    st.session_state.model = None
if "scaler" not in st.session_state:
    st.session_state.scaler = None

# ====== UI ELEMENTS ======
st.title("🧠 MarketBrain AI Trader")
ssid = st.text_input("Paste your Pocket Option SSID:")
telegram_token = st.text_input("Telegram Bot Token", type="password")
telegram_chat = st.text_input("Telegram Chat ID")
assets = st.multiselect("Choose Assets", ["EURUSD", "GBPUSD", "BTCUSD", "ETHUSD", "AAPL"], default=["EURUSD", "GBPUSD"])
risk_mode = st.checkbox("Enable Risk Mode (Max 8 trades per day)", value=True)
test_alert = st.button("Send Test Alert to Telegram")
start_trade = st.button("Start Live Trading")

# ====== TELEGRAM FUNCTION ======
def send_telegram(text):
    try:
        if telegram_token and telegram_chat:
            Bot(token=telegram_token).send_message(chat_id=telegram_chat, text=text)
    except:
        st.warning("❌ Failed to send Telegram message")

if test_alert:
    send_telegram("✅ Test alert from MarketBrain AI!")

# ====== FETCH PRICE FROM ALPHA ======
def fetch_price_data(symbol="EURUSD"):
    ts = TimeSeries(key=ALPHA_KEY, output_format="pandas")
    data, _ = ts.get_intraday(symbol=symbol, interval="15min", outputsize="full")
    return data["4. close"].iloc[::-1].reset_index(drop=True)

# ====== GET NEWS SENTIMENT ======
def get_news_sentiment():
    r = requests.get(f"https://newsapi.org/v2/everything?q=forex&apiKey={NEWSAPI_KEY}&pageSize=50").json()
    pos, neg = 0, 0
    for a in r.get("articles", []):
        t = (a["title"] + a.get("description", "")).lower()
        if any(w in t for w in ["rise", "profit", "gain", "strong", "growth"]): pos += 1
        if any(w in t for w in ["fall", "loss", "drop", "weak", "fear"]): neg += 1
    return (pos - neg) / max((pos + neg), 1)

# ====== GET FINNHUB SENTIMENT ======
def get_finnhub_sentiment():
    r = requests.get(f"https://finnhub.io/api/v1/news-sentiment?symbol=AAPL&token={FINNHUB_KEY}").json()
    return r.get("sentiment", {}).get("bullishPercent", 50) / 100

# ====== BUILD LSTM INPUT ======
def build_input(prices, sentiment, finnhub):
    prices = prices[-60:]
    scaled = st.session_state.scaler.transform(prices.values.reshape(-1, 1))
    sentiment_col = np.full((60, 1), sentiment)
    finnhub_col = np.full((60, 1), finnhub)
    return np.expand_dims(np.hstack((scaled, sentiment_col, finnhub_col)), axis=0)

# ====== TRADE FUNCTION ======
def execute_trade(signal, asset, demo=True):
    if not ssid: return
    mode = "demo" if demo else "real"
    headers = {"Cookie": f"SSID={ssid}"}
    payload = {
        "direction": "call" if signal == 1 else "put",
        "asset": asset,
        "amount": 1,
        "expired": 60,
        "type": "turbo",
        "mode": mode
    }
    try:
        r = requests.post(POCKET_TRADE_URL, headers=headers, data=payload)
        if r.status_code == 200:
            send_telegram(f"✅ Trade placed on {asset} ({'BUY' if signal == 1 else 'SELL'})")
            st.session_state.trade_count += 1
    except Exception as e:
        st.warning("Trade failed")

# ====== MODEL INFERENCE ======
def predict_and_trade(asset):
    if st.session_state.trade_count >= TRADE_LIMIT and risk_mode:
        send_telegram("🛑 Daily trade limit reached.")
        return
    try:
        prices = fetch_price_data(asset)
        sentiment = get_news_sentiment()
        finnhub = get_finnhub_sentiment()
        X = build_input(prices, sentiment, finnhub)
        y_pred = st.session_state.model.predict(X)
        signal = 1 if y_pred[0][0] > 0.5 else 0
        confidence = round(float(y_pred[0][0]) * 100, 2)
        st.write(f"{asset} ➜ Prediction: {'BUY' if signal else 'SELL'} | Confidence: {confidence}%")
        send_telegram(f"📈 {asset} Signal: {'BUY' if signal else 'SELL'} | Confidence: {confidence}%")
        if confidence > 70:
            execute_trade(signal, asset)
    except Exception as e:
        st.error(f"Error for {asset}: {e}")

# ====== LOAD MODEL ======
try:
    if st.session_state.model is None:
        st.session_state.model = load_model("lstm_model_news_sentiment.h5")
        st.session_state.scaler = joblib.load("scaler_multi.save")
        st.success("✅ Model loaded")
except:
    st.warning("⚠️ Model or scaler not found")

# ====== TRADING LOOP ======
if start_trade:
    if not ssid:
        st.warning("Enter your Pocket Option SSID to trade.")
    else:
        send_telegram("🚀 Auto-trading started.")
        while st.session_state.trade_count < TRADE_LIMIT if risk_mode else True:
            for a in assets:
                predict_and_trade(a)
                time.sleep(3)
            st.write("Waiting for next cycle...")
            time.sleep(15 * 60)
